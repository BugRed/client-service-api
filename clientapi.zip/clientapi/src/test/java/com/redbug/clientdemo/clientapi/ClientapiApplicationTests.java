package com.redbug.clientdemo.clientapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
